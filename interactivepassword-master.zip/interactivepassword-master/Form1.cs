namespace interactivepassword
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpassword_MouseEnter(object sender, EventArgs e)
        {
            // Removing the PasswordChar reveals the plain text
            txtPassword.UseSystemPasswordChar = false;
            txtPassword.PasswordChar = '\0';
            lblStatus.Text = "Status: Password Revealed";
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtPassword_MouseLeave(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
            lblStatus.Text = "Status: Ready";
        }

        private void txtPassword_MouseDown(object sender, MouseEventArgs e)
        {
            // Right-click: Generate random password
            if (e.Button == MouseButtons.Right)
            {
                string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789!@#$%";
                Random random = new Random();
                char[] password = new char[10];

                for (int i = 0; i < 10; i++)
                {
                    password[i] = validChars[random.Next(validChars.Length)];
                }

                txtPassword.Text = new string(password);
                lblStatus.Text = "Status: Random Password Generated";
            }
            // Left-click: Copy to clipboard
            else if (e.Button == MouseButtons.Left)
            {
                if (!string.IsNullOrEmpty(txtPassword.Text))
                {
                    Clipboard.SetText(txtPassword.Text);
                    lblStatus.Text = "Status: Copied to Clipboard";
                }
            }
        }

        private void txtPassword_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txtPassword.Clear();
            lblStatus.Text = "Status: Field Cleared";
        }
    }
}
