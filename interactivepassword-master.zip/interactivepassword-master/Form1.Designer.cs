﻿namespace interactivepassword
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtPassword = new TextBox();
            panel1 = new Panel();
            lblStatus = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            label1.Location = new Point(172, 32);
            label1.Name = "label1";
            label1.Size = new Size(411, 45);
            label1.TabIndex = 0;
            label1.Text = "Interactive Password Field";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ControlDarkDark;
            label2.Location = new Point(35, 270);
            label2.Name = "label2";
            label2.Size = new Size(168, 25);
            label2.TabIndex = 3;
            label2.Text = "Interactive Features:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ControlDarkDark;
            label3.Location = new Point(35, 306);
            label3.Name = "label3";
            label3.Size = new Size(221, 25);
            label3.TabIndex = 4;
            label3.Text = "• Hover - Reveal password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(35, 331);
            label4.Name = "label4";
            label4.Size = new Size(346, 25);
            label4.TabIndex = 5;
            label4.Text = "• Right-Click - Generate random password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = SystemColors.ControlDarkDark;
            label5.Location = new Point(35, 356);
            label5.Name = "label5";
            label5.Size = new Size(257, 25);
            label5.TabIndex = 6;
            label5.Text = "• Left-Click - Copy to clipboard";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = SystemColors.ControlDarkDark;
            label6.Location = new Point(35, 381);
            label6.Name = "label6";
            label6.Size = new Size(263, 25);
            label6.TabIndex = 7;
            label6.Text = "• Double-Click - Clear password";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(152, 30);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(370, 31);
            txtPassword.TabIndex = 1;
            txtPassword.TextChanged += txtpassword_TextChanged;
            txtPassword.MouseDoubleClick += txtPassword_MouseDoubleClick;
            txtPassword.MouseDown += txtPassword_MouseDown;
            txtPassword.MouseEnter += txtpassword_MouseEnter;
            txtPassword.MouseLeave += txtPassword_MouseLeave;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.AppWorkspace;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(txtPassword);
            panel1.Location = new Point(35, 91);
            panel1.Name = "panel1";
            panel1.Size = new Size(729, 164);
            panel1.TabIndex = 2;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI Black", 12F);
            lblStatus.ForeColor = SystemColors.Highlight;
            lblStatus.Location = new Point(188, 433);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(174, 32);
            lblStatus.TabIndex = 8;
            lblStatus.Text = "Status: Ready";
            lblStatus.Click += label7_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 572);
            Controls.Add(lblStatus);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            TextChanged += Form1_TextChanged;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtPassword;
        private Panel panel1;
        private Label lblStatus;
    }
}
